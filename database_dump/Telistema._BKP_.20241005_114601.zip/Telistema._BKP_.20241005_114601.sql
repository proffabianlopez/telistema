-- MySQL dump 10.13  Distrib 8.4.0, for Linux (x86_64)
--
-- Host: localhost    Database: telistema
-- ------------------------------------------------------
-- Server version-8.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `buys`
--

DROP TABLE IF EXISTS `buys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buys` (
  `id_buy` int NOT NULL AUTO_INCREMENT,
  `remittance` varchar(13) NOT NULL,
  `date_buy` datetime NOT NULL,
  `ammount` int NOT NULL,
  `cost` double NOT NULL,
  `id_supplier` int NOT NULL,
  `id_material` int NOT NULL,
  `id_measure` tinyint NOT NULL,
  `id_user` int NOT NULL,
  `id_state_order` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_buy`),
  KEY `id_supplier` (`id_supplier`,`id_material`),
  KEY `id_material` (`id_material`),
  KEY `id_state_order` (`id_state_order`),
  KEY `buys_ibfk_4` (`id_user`),
  KEY `buys_ibfk_5` (`id_measure`),
  CONSTRAINT `buys_ibfk_1` FOREIGN KEY (`id_material`) REFERENCES `materials` (`id_material`) ON UPDATE CASCADE,
  CONSTRAINT `buys_ibfk_2` FOREIGN KEY (`id_state_order`) REFERENCES `states_orders` (`id_state_order`) ON UPDATE CASCADE,
  CONSTRAINT `buys_ibfk_3` FOREIGN KEY (`id_supplier`) REFERENCES `suppliers` (`id_supplier`) ON UPDATE CASCADE,
  CONSTRAINT `buys_ibfk_4` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`) ON UPDATE CASCADE,
  CONSTRAINT `buys_ibfk_5` FOREIGN KEY (`id_measure`) REFERENCES `measures` (`id_measure`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buys`
--

LOCK TABLES `buys` WRITE;
/*!40000 ALTER TABLE `buys` DISABLE KEYS */;
/*!40000 ALTER TABLE `buys` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_insert_buys` AFTER INSERT ON `buys` FOR EACH ROW INSERT INTO buys_audits(action, modify, id_buy,date_buy,ammount,cost,id_supplier,id_material,id_measure, id_user,id_state_order) VALUES("insert", NOW(), NEW.id_buy, NEW.date_buy, NEW.ammount,NEW.cost,NEW.id_supplier, NEW.id_material,NEW.id_measure,NEW.id_user,NEW.id_state_order) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_buy` AFTER UPDATE ON `buys` FOR EACH ROW BEGIN
    IF NEW.id_state_order = 4 THEN
        UPDATE materials
        SET stock = stock + NEW.ammount
        WHERE id_material = NEW.id_material;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_update_buys` AFTER UPDATE ON `buys` FOR EACH ROW INSERT INTO buys_audits(action, modify, id_buy,date_buy,ammount,cost,id_supplier,id_material,id_measure,id_user,id_state_order) VALUES("UPDATE", NOW(), NEW.id_buy, NEW.date_buy, NEW.ammount,NEW.cost,NEW.id_supplier, NEW.id_material,NEW.id_measure,NEW.id_user,NEW.id_state_order) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_delete_buys` AFTER DELETE ON `buys` FOR EACH ROW INSERT INTO buys_audits(action, modify, id_buy,date_buy,ammount,cost,id_supplier,id_material,id_measure,id_user,id_state_order) VALUES("delete", NOW(), Old.id_buy, Old.date_buy, Old.ammount, Old.cost, Old.id_supplier, Old.id_material,Old.id_measure, Old.id_user, Old.id_state_order) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `buys_audits`
--

DROP TABLE IF EXISTS `buys_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `buys_audits` (
  `id_buy_audits` int NOT NULL AUTO_INCREMENT,
  `action` varchar(60) NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_buy` int NOT NULL,
  `date_buy` date NOT NULL,
  `ammount` int NOT NULL,
  `cost` double NOT NULL,
  `id_supplier` int NOT NULL,
  `id_material` int NOT NULL,
  `id_measure` tinyint NOT NULL,
  `id_user` int NOT NULL,
  `id_state_order` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_buy_audits`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buys_audits`
--

LOCK TABLES `buys_audits` WRITE;
/*!40000 ALTER TABLE `buys_audits` DISABLE KEYS */;
/*!40000 ALTER TABLE `buys_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id_client` int NOT NULL AUTO_INCREMENT,
  `client_name` varchar(100) NOT NULL,
  `client_lastname` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mail` varchar(150) NOT NULL,
  `address` varchar(100) NOT NULL,
  `height` int DEFAULT NULL,
  `floor` varchar(10) DEFAULT NULL,
  `departament` varchar(10) DEFAULT NULL,
  `id_state_user` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_client`),
  KEY `id_status_user` (`id_state_user`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`id_state_user`) REFERENCES `states_users` (`id_state_user`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (4,'Betrini','Seguros','+5491150365236','betriniSeg@gmail.com','Almafuerte',122,'1','2',1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_insert_clients_` AFTER INSERT ON `clients` FOR EACH ROW INSERT INTO clients_audits(action, modify, id_client, client_name, client_lastname, phone, mail, address, height, floor, departament, id_state_user) VALUES("insert", NOW(), NEW.id_client, NEW.client_name, NEW.client_lastname, NEW.phone, NEW.mail, NEW.address, NEW.height, NEW.floor, NEW.departament, NEW.id_state_user) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_update_clients` AFTER UPDATE ON `clients` FOR EACH ROW INSERT INTO clients_audits(action, modify, id_client, client_name, client_lastname, phone, mail, address, height, floor, departament, id_state_user) VALUES("update", NOW(), NEW.id_client, NEW.client_name, NEW.client_lastname, NEW.phone, NEW.mail, NEW.address, NEW.height, NEW.floor, NEW.departament, NEW.id_state_user) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_delete_clients` AFTER DELETE ON `clients` FOR EACH ROW INSERT INTO clients_audits(action, modify, id_client, client_name, client_lastname, phone, mail, address, height, floor, departament, id_state_user) VALUES("delete", NOW(), Old.id_client, Old.client_name, Old.client_lastname, Old.phone, Old.mail, Old.address, Old.height, Old.floor, Old.departament, Old.id_state_user) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `clients_audits`
--

DROP TABLE IF EXISTS `clients_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients_audits` (
  `id_client_audit` int NOT NULL AUTO_INCREMENT,
  `action` varchar(60) NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_client` int NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_lastname` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mail` varchar(150) NOT NULL,
  `address` varchar(100) NOT NULL,
  `height` int NOT NULL,
  `floor` varchar(10) NOT NULL,
  `departament` varchar(10) NOT NULL,
  `id_state_user` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_client_audit`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients_audits`
--

LOCK TABLES `clients_audits` WRITE;
/*!40000 ALTER TABLE `clients_audits` DISABLE KEYS */;
INSERT INTO `clients_audits` VALUES (10,'insert','2024-09-23 20:04:48',5,'Yazmín','Penayo','5491133445566','yaz.penayo@gmail.com','San Lorenzo',1344,'','',1),(11,'update','2024-09-23 20:05:00',5,'Yazmín','Penayo','5491133445566','yaz.penayo@gmail.com','San Lorenzo',1344,'','',2),(12,'update','2024-09-30 21:58:36',4,'Betrini','Seguros','+5491150365236','betriniSeg@gmail.com','Almafuerte',122,'1','2',1),(13,'update','2024-09-30 21:58:36',5,'Yazmín','Penayo','+5491120365236','yaz.penayo@gmail.com','San Lorenzo',1344,'','',2),(14,'delete','2024-09-30 22:09:10',5,'Yazmín','Penayo','+5491120365236','yaz.penayo@gmail.com','San Lorenzo',1344,'','',2);
/*!40000 ALTER TABLE `clients_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configs_emails`
--

DROP TABLE IF EXISTS `configs_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `configs_emails` (
  `id_config_email` tinyint(1) NOT NULL AUTO_INCREMENT,
  `mail_host` varchar(150) NOT NULL,
  `mail_port` int NOT NULL,
  `mail_username` varchar(150) NOT NULL,
  `mail_password` varchar(255) NOT NULL,
  `mail_setfrom` varchar(150) NOT NULL,
  `mail_addaddress` varchar(150) NOT NULL,
  `webpage` varchar(150) NOT NULL,
  PRIMARY KEY (`id_config_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configs_emails`
--

LOCK TABLES `configs_emails` WRITE;
/*!40000 ALTER TABLE `configs_emails` DISABLE KEYS */;
INSERT INTO `configs_emails` VALUES (1,'smtp.gmail.com',587,'fabri22sas@gmail.com','show doav ghka ciyd','fabri22sas@gmail.com','luka17sas@gmail.com','www.telistema.com.ar');
/*!40000 ALTER TABLE `configs_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `id_image` int NOT NULL AUTO_INCREMENT,
  `name_image` varchar(255) NOT NULL,
  `id_order` int NOT NULL,
  PRIMARY KEY (`id_image`),
  KEY `id_order` (`id_order`),
  CONSTRAINT `images_ibfk_1` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id_order`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (14,'../../img/d_nq_np_635437-mlu69451087297_052023-o-a0e1e24441c2c73c7517055419951819-1024-1024.webp',19),(15,'../../img/PAU-Router.jpg',20),(16,'../../img/esquema2.jpg',20),(17,'../../img/DALL·E 2024-08-19 12.12.09 - A dark-themed illustration showing a Man-in-the-Middle (MitM) cyber attack. In the center, a hooded hacker with a laptop sits in a shadowy environment.webp',24),(18,'../../img/ISFT-177.png',25),(19,'../../img/429287.png',25),(20,'../../img/429287 (1).png',25);
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materials` (
  `id_material` int NOT NULL AUTO_INCREMENT,
  `material_name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `stock` int DEFAULT NULL,
  `stock_alert` int DEFAULT NULL,
  `id_measure` tinyint(1) NOT NULL,
  `id_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_material`),
  KEY `material_ibfk_1` (`id_measure`),
  CONSTRAINT `material_ibfk_1` FOREIGN KEY (`id_measure`) REFERENCES `measures` (`id_measure`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials`
--

LOCK TABLES `materials` WRITE;
/*!40000 ALTER TABLE `materials` DISABLE KEYS */;
INSERT INTO `materials` VALUES (2,'Media Converter','Media Converter 30km\"',120,1,1,1),(7,'Camaras Domo','Exterior Ip 3mp Full Hd Nocturna Audio Alarma',10,80,2,2);
/*!40000 ALTER TABLE `materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `materials_audits`
--

DROP TABLE IF EXISTS `materials_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materials_audits` (
  `id_material_audit` int NOT NULL AUTO_INCREMENT,
  `action` varchar(60) NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_material` int NOT NULL,
  `material_name` varchar(255) NOT NULL,
  `critical_point` float NOT NULL,
  PRIMARY KEY (`id_material_audit`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materials_audits`
--

LOCK TABLES `materials_audits` WRITE;
/*!40000 ALTER TABLE `materials_audits` DISABLE KEYS */;
/*!40000 ALTER TABLE `materials_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `measures`
--

DROP TABLE IF EXISTS `measures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `measures` (
  `id_measure` tinyint NOT NULL AUTO_INCREMENT,
  `name_measure` varchar(20) NOT NULL,
  PRIMARY KEY (`id_measure`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `measures`
--

LOCK TABLES `measures` WRITE;
/*!40000 ALTER TABLE `measures` DISABLE KEYS */;
INSERT INTO `measures` VALUES (1,'Metros'),(2,'Unidad'),(3,'Kilos'),(4,'Centimetros'),(5,'Milimetros');
/*!40000 ALTER TABLE `measures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id_order` int NOT NULL AUTO_INCREMENT,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_description` mediumtext NOT NULL,
  `order_server` int DEFAULT NULL,
  `address` varchar(50) NOT NULL,
  `height` int NOT NULL,
  `floor` varchar(10) DEFAULT NULL,
  `departament` varchar(10) DEFAULT NULL,
  `report_technic` mediumtext,
  `circuit_number` int NOT NULL,
  `id_type_work` int NOT NULL,
  `id_client` int NOT NULL,
  `id_priority` int NOT NULL,
  `id_material` int DEFAULT NULL,
  `id_state_order` tinyint(1) NOT NULL,
  `admin_id` int DEFAULT NULL,
  `technic_id` int DEFAULT NULL,
  PRIMARY KEY (`id_order`),
  KEY `id_client` (`id_client`,`id_material`,`id_state_order`),
  KEY `id_state_order` (`id_state_order`),
  KEY `id_material` (`id_material`),
  KEY `id_priority` (`id_priority`),
  KEY `fk_admin_id` (`admin_id`),
  KEY `fk_technic_id` (`technic_id`),
  KEY `id_type_work` (`id_type_work`),
  CONSTRAINT `fk_admin_id` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id_user`),
  CONSTRAINT `fk_technic_id` FOREIGN KEY (`technic_id`) REFERENCES `users` (`id_user`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`id_state_order`) REFERENCES `states_orders` (`id_state_order`) ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`id_priority`) REFERENCES `prioritys` (`id_priority`) ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`id_client`) REFERENCES `clients` (`id_client`) ON UPDATE CASCADE,
  CONSTRAINT `orders_ibfk_4` FOREIGN KEY (`id_type_work`) REFERENCES `types_works` (`id_type_work`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (19,'2024-09-30 18:43:22','colocar camara domo',NULL,'Calle Real',1655,'','','Instalada con exito',1,1,4,1,NULL,5,1,6),(20,'2024-09-30 18:43:28','restaurar la fibra',NULL,'Calle Real Y 25 De Mayo',0,'','','Instalado',3,2,4,2,NULL,5,1,6),(21,'2024-09-30 18:43:31','colocar fibra optica',NULL,'Calle Real',1344,'1','2',NULL,5,1,4,1,NULL,5,1,6),(22,'2024-09-30 15:42:29','..........',NULL,'Calle Real',1111,'','',NULL,12,2,4,1,NULL,3,1,6),(23,'2024-09-30 18:59:06','Instalar una camara con ALTO ZOOM',NULL,'Beltran Y 25 De Mayo',0,'','',NULL,1,1,4,2,NULL,3,1,6),(24,'2024-10-01 04:27:10','TEST',NULL,'Test',123,'2','B','Ready',123213,1,4,2,NULL,4,1,6),(25,'2024-10-04 13:50:46','123123qwe',NULL,'Weasea',123,'','','asdas',1,1,4,2,NULL,4,1,6),(26,'2024-10-01 23:45:28','sadsa',NULL,'Ripamonti',22,'','',NULL,2,2,4,2,NULL,3,1,6);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_insert_orders` AFTER INSERT ON `orders` FOR EACH ROW INSERT INTO orders_audits(action, modify, id_order, order_date, order_description, order_server, address, height, floor, departament,report_technic, circuit_number, id_type_work, id_client, id_priority, id_material, id_state_order, admin_id, technic_id) VALUES("insert", NOW(), NEW.id_order, NEW.order_date, NEW.order_description, NEW.order_server, NEW.address, NEW.height, NEW.floor, NEW.departament, NEW.report_technic, NEW.circuit_number, NEW.id_type_work, NEW.id_client, NEW.id_priority, NEW.id_material, NEW.id_state_order, NEW.admin_id, NEW.technic_id) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_update_orders` AFTER UPDATE ON `orders` FOR EACH ROW INSERT INTO orders_audits(action, modify, id_order, order_date, order_description, order_server, address, height, floor, departament, report_technic, circuit_number, id_type_work, id_client, id_priority, id_material, id_state_order, admin_id, technic_id) VALUES("update", NOW(), NEW.id_order, NEW.order_date, NEW.order_description, NEW.order_server, NEW.address, NEW.height, NEW.floor, NEW.departament, NEW.report_technic, NEW.circuit_number, NEW.id_type_work, NEW.id_client, NEW.id_priority, NEW.id_material, NEW.id_state_order, NEW.admin_id, NEW.technic_id) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_delete_orders` AFTER DELETE ON `orders` FOR EACH ROW INSERT INTO orders_audits(action, modify, id_order, order_date, order_description, order_server, address, height, floor, departament, report_technic, circuit_number, id_type_work ,id_client, id_priority, id_material, id_state_order, admin_id, technic_id) VALUES("delete", NOW(), Old.id_order, Old.order_date, Old.order_description, Old.order_server, Old.address, Old.height, Old.floor, Old.departament, Old.report_technic, Old.circuit_number, Old.id_type_work, Old.id_client, Old.id_priority, Old.id_material, Old.id_state_order, Old.admin_id, Old.technic_id) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `orders_audits`
--

DROP TABLE IF EXISTS `orders_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_audits` (
  `id_order_audit` int NOT NULL AUTO_INCREMENT,
  `action` varchar(60) NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_order` int NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_description` mediumtext NOT NULL,
  `order_server` int DEFAULT NULL,
  `address` varchar(50) NOT NULL,
  `height` int NOT NULL,
  `floor` varchar(10) DEFAULT NULL,
  `departament` varchar(10) DEFAULT NULL,
  `report_technic` mediumtext,
  `circuit_number` int NOT NULL,
  `id_type_work` int NOT NULL,
  `id_client` int NOT NULL,
  `id_priority` int NOT NULL,
  `id_material` int DEFAULT NULL,
  `id_state_order` tinyint(1) NOT NULL,
  `admin_id` int DEFAULT NULL,
  `technic_id` int DEFAULT NULL,
  PRIMARY KEY (`id_order_audit`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders_audits`
--

LOCK TABLES `orders_audits` WRITE;
/*!40000 ALTER TABLE `orders_audits` DISABLE KEYS */;
INSERT INTO `orders_audits` VALUES (74,'insert','2024-09-24 14:48:07',19,'2024-09-24 11:48:07','colocar camara domo',NULL,'Calle Real',1655,'','',NULL,1,1,4,1,NULL,3,1,6),(75,'update','2024-09-24 14:50:40',19,'2024-09-24 14:50:40','colocar camara domo',NULL,'Calle Real',1655,'','','Instalada con exito',1,1,4,1,NULL,4,1,6),(76,'insert','2024-09-24 14:51:48',20,'2024-09-24 11:51:48','restaurar la fibra',NULL,'Calle Real Y 25 De Mayo',0,'','',NULL,3,2,4,2,NULL,3,1,6),(77,'update','2024-09-24 14:53:17',20,'2024-09-24 14:53:17','restaurar la fibra',NULL,'Calle Real Y 25 De Mayo',0,'','','Instalado',3,2,4,2,NULL,4,1,6),(78,'insert','2024-09-24 14:54:52',21,'2024-09-24 11:54:52','colocar fibra optica',NULL,'Calle Real',1344,'1','2',NULL,5,1,4,1,NULL,3,1,6),(79,'insert','2024-09-30 18:42:29',22,'2024-09-30 15:42:29','..........',NULL,'Calle Real',1111,'','',NULL,12,2,4,1,NULL,3,1,6),(80,'update','2024-09-30 18:43:22',19,'2024-09-30 18:43:22','colocar camara domo',NULL,'Calle Real',1655,'','','Instalada con exito',1,1,4,1,NULL,5,1,6),(81,'update','2024-09-30 18:43:28',20,'2024-09-30 18:43:28','restaurar la fibra',NULL,'Calle Real Y 25 De Mayo',0,'','','Instalado',3,2,4,2,NULL,5,1,6),(82,'update','2024-09-30 18:43:31',21,'2024-09-30 18:43:31','colocar fibra optica',NULL,'Calle Real',1344,'1','2',NULL,5,1,4,1,NULL,5,1,6),(83,'insert','2024-09-30 21:54:52',23,'2024-09-30 18:54:52','Instalar una camara con ALTO ZOOM',NULL,'Beltran Y 25 De Mayo',0,'','',NULL,1,1,4,1,NULL,3,1,6),(84,'update','2024-09-30 21:59:06',23,'2024-09-30 18:59:06','Instalar una camara con ALTO ZOOM',NULL,'Beltran Y 25 De Mayo',0,'','',NULL,1,1,4,2,NULL,3,1,6),(85,'insert','2024-10-01 04:25:14',24,'2024-10-01 01:25:14','TEST',NULL,'Test',123,'2','B',NULL,123213,1,4,2,NULL,3,1,6),(86,'update','2024-10-01 04:27:10',24,'2024-10-01 04:27:10','TEST',NULL,'Test',123,'2','B','Ready',123213,1,4,2,NULL,4,1,6),(87,'insert','2024-10-04 13:50:25',25,'2024-10-04 10:50:25','123123qwe',NULL,'Weasea',123,'','',NULL,1,1,4,2,NULL,3,1,6),(88,'update','2024-10-04 13:50:46',25,'2024-10-04 13:50:46','123123qwe',NULL,'Weasea',123,'','','asdas',1,1,4,2,NULL,4,1,6),(89,'insert','2024-10-02 02:45:28',26,'2024-10-01 23:45:28','sadsa',NULL,'Ripamonti',22,'','',NULL,2,2,4,2,NULL,3,1,6);
/*!40000 ALTER TABLE `orders_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_levels`
--

DROP TABLE IF EXISTS `password_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_levels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `level_name` varchar(50) NOT NULL,
  `description` mediumtext,
  `min_length` int NOT NULL,
  `requires_uppercase` tinyint(1) NOT NULL,
  `requires_digit` tinyint(1) NOT NULL,
  `requires_special_char` tinyint(1) NOT NULL,
  `special_conditions` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_levels`
--

LOCK TABLES `password_levels` WRITE;
/*!40000 ALTER TABLE `password_levels` DISABLE KEYS */;
INSERT INTO `password_levels` VALUES (1,'Medio','Longitud mínima de 8 caracteres, al menos una mayúscula y un número',8,1,1,0,''),(2,'Alto','Longitud mínima de 12 caracteres, al menos una mayúscula, un número y un símbolo',12,1,1,1,'Debe contener al menos un símbolo');
/*!40000 ALTER TABLE `password_levels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prioritys`
--

DROP TABLE IF EXISTS `prioritys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prioritys` (
  `id_priority` int NOT NULL AUTO_INCREMENT,
  `priority` varchar(60) NOT NULL,
  PRIMARY KEY (`id_priority`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prioritys`
--

LOCK TABLES `prioritys` WRITE;
/*!40000 ALTER TABLE `prioritys` DISABLE KEYS */;
INSERT INTO `prioritys` VALUES (1,'Normal'),(2,'Urgente');
/*!40000 ALTER TABLE `prioritys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id_rol` int NOT NULL AUTO_INCREMENT,
  `rol` varchar(50) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador'),(2,'Técnico');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states_orders`
--

DROP TABLE IF EXISTS `states_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states_orders` (
  `id_state_order` tinyint(1) NOT NULL AUTO_INCREMENT,
  `state_order` varchar(100) NOT NULL,
  PRIMARY KEY (`id_state_order`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states_orders`
--

LOCK TABLES `states_orders` WRITE;
/*!40000 ALTER TABLE `states_orders` DISABLE KEYS */;
INSERT INTO `states_orders` VALUES (2,'Cancelada'),(3,'Pendiente'),(4,'Realizada'),(5,'Inactiva');
/*!40000 ALTER TABLE `states_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states_users`
--

DROP TABLE IF EXISTS `states_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states_users` (
  `id_state_user` tinyint(1) NOT NULL AUTO_INCREMENT,
  `state_user` varchar(20) NOT NULL,
  PRIMARY KEY (`id_state_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states_users`
--

LOCK TABLES `states_users` WRITE;
/*!40000 ALTER TABLE `states_users` DISABLE KEYS */;
INSERT INTO `states_users` VALUES (1,'activo'),(2,'inactivo');
/*!40000 ALTER TABLE `states_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id_supplier` int NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mail` varchar(150) NOT NULL,
  `address` varchar(100) NOT NULL,
  `id_state_user` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_supplier`),
  KEY `id_state_user` (`id_state_user`),
  CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`id_state_user`) REFERENCES `states_users` (`id_state_user`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (1,'El Segundo Srl','5491112345678','admin@gmail.com','Las Piedras 123',1),(2,'Belgrano Sa','5491122334455','belgrano@gmail.com','San Lorenzo 897',1);
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_insert_suppliers` AFTER INSERT ON `suppliers` FOR EACH ROW INSERT INTO suppliers_audits(action, modify, id_supplier, supplier_name, phone, mail, address, id_state_user) VALUES("insert", NOW(), NEW.id_supplier, NEW.supplier_name, NEW.phone, NEW.mail, NEW.address, NEW.id_state_user) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_update_suppliers` AFTER UPDATE ON `suppliers` FOR EACH ROW INSERT INTO suppliers_audits(action, modify, id_supplier, supplier_name, phone, mail, address, id_state_user) VALUES("update", NOW(), NEW.id_supplier, NEW.supplier_name, NEW.phone, NEW.mail, NEW.address, NEW.id_state_user) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`%`*/ /*!50003 TRIGGER `after_delete_suppliers` AFTER DELETE ON `suppliers` FOR EACH ROW INSERT INTO suppliers_audits(action, modify, id_supplier, supplier_name, phone, mail, address, id_state_user) VALUES("delete", NOW(), Old.id_supplier, Old.supplier_name, Old.phone, Old.mail, Old.address, Old.id_state_user) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `suppliers_audits`
--

DROP TABLE IF EXISTS `suppliers_audits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers_audits` (
  `id_supplier_audit` int NOT NULL AUTO_INCREMENT,
  `action` varchar(60) NOT NULL,
  `modify` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_supplier` int NOT NULL,
  `supplier_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mail` varchar(150) NOT NULL,
  `address` varchar(100) NOT NULL,
  `id_state_user` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_supplier_audit`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers_audits`
--

LOCK TABLES `suppliers_audits` WRITE;
/*!40000 ALTER TABLE `suppliers_audits` DISABLE KEYS */;
/*!40000 ALTER TABLE `suppliers_audits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `types_works`
--

DROP TABLE IF EXISTS `types_works`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `types_works` (
  `id_type_work` int NOT NULL AUTO_INCREMENT,
  `type_work` varchar(100) NOT NULL,
  PRIMARY KEY (`id_type_work`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `types_works`
--

LOCK TABLES `types_works` WRITE;
/*!40000 ALTER TABLE `types_works` DISABLE KEYS */;
INSERT INTO `types_works` VALUES (1,'Alta'),(2,'Reparación');
/*!40000 ALTER TABLE `types_works` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id_user` int NOT NULL AUTO_INCREMENT,
  `name_user` varchar(150) NOT NULL,
  `surname_user` varchar(20) NOT NULL,
  `phone_user` varchar(50) NOT NULL,
  `mail` varchar(150) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `id_state_user` tinyint(1) NOT NULL,
  `id_rol` int NOT NULL,
  PRIMARY KEY (`id_user`),
  UNIQUE KEY `mail` (`mail`),
  KEY `id_state_user` (`id_state_user`,`id_rol`),
  KEY `id_rol` (`id_rol`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON UPDATE CASCADE,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`id_state_user`) REFERENCES `states_users` (`id_state_user`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','Test','+5491150369856','admin@gmail.com','$2y$10$wvsEcncz3oAXImAgX5CYve4J2sFqTwEq7DnKzFVVbK3S.WT3gq/nK',1,1),(6,'Tecnico','Test','+5491178965236','tecnico@gmail.com','$2y$10$Ngj79FdQ6.oWTbne9OUqv.HZQl2t1sLltwsty0gqtocejprCFoPEa',1,2),(7,'Pablo ','Telistema','+5491169859845','pablo_telistema@gmail.com','$2y$10$sH1g0YNJTEjvLGATR4i4u.YVaENiD4vcmwk2s8IL7e8qQhgltZf46',1,1),(8,'VÃ­ctor Fede','Brigadab','+5491178964552','camion1@gmail.com','$2y$10$QfvKdGhAgsF32q7bdMeLtuL/DUTlrq2BNZNzHgP6HPRZxX7ofQ18q',1,2);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-05 14:46:01
